package university;

public class Student
{
    private int id;
    private String name;
    private double gpa;
    private Advisor theAdvisor;

    public Student(String name, Advisor advisor)
    {
        this.name = name;
        this.theAdvisor = advisor;
    }

    public Student(int id, double gpa)
    {
        this.id = id;
        this.gpa = gpa;
    }

    public Student() {}
    
    public Advisor getTheAdvisor()
    {
        return theAdvisor;
    }

    public void setTheAdvisor(Advisor theAdvisor)
    {
        this.theAdvisor = theAdvisor;
    }

    public int getId()
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public double getGpa()
    {
        return gpa;
    }

    public void setGpa(double gpa)
    {
        this.gpa = gpa;
    }

    @Override
    public String toString()
    {
        return "ID: " + id + " name: " + name + " GPA: " + gpa;
    }
}
