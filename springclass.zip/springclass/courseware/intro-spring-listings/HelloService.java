package hello;

public interface HelloService
{
    public void sayHello();
}
