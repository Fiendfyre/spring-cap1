package client;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class PutClient
{
    public static void main(String[] args) throws Exception
    {
        URL url = 
          new URL(
            "http://localhost:9081/TestRestCRUDWeb/rest/students");
        HttpURLConnection conn = 
          (HttpURLConnection) url.openConnection();
        conn.setDoOutput(true);
        conn.setRequestMethod("PUT");
        conn.setRequestProperty("Content-Type", "application/json");

        String input = 
          "{\"name\":\"Joe Blow\",\"gpa\":4.56, \"studentId\":12}";

        OutputStream os = conn.getOutputStream();
        os.write(input.getBytes());
        os.flush();

        if (conn.getResponseCode() != 
           HttpURLConnection.HTTP_NO_CONTENT)
        {
            throw new RuntimeException("Failed : HTTP error code : "
                    + conn.getResponseCode());
        }

        conn.disconnect();
    }
}
