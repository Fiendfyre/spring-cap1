package edu.bigcollege.listeners;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import edu.bigcollege.Student;

public class MyContextListener implements ServletContextListener
{

    @Override
    public void contextDestroyed(ServletContextEvent ctx)
    {
    }

    @Override
    public void contextInitialized(ServletContextEvent ctx)
    {
        System.out.println("Context initialized");
        List<Student> students = new ArrayList<Student>();

        Student c = new Student();
        c.setGpa(3.44);
        c.setName("Sue Smith");
        c.setStudentId(12);
        students.add(c);

        c = new Student();
        c.setGpa(3.87);
        c.setName("Bill Jones");
        c.setStudentId(44);
        students.add(c);

        ctx.getServletContext().setAttribute("students", students);
    }

}
