package client;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class PostClient
{
    public static void main(String[] args) throws Exception
    {
        URL url = 
          new URL(
           "http://localhost:9081/TestRestCRUDWeb/rest/students");
        HttpURLConnection conn = 
          (HttpURLConnection) url.openConnection();
        conn.setDoOutput(true);
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");

        String input = "{\"name\":\"Harry Wolfe\",\"gpa\":2.22}";

        OutputStream os = conn.getOutputStream();
        os.write(input.getBytes());
        os.flush();

        if (conn.getResponseCode() != HttpURLConnection.HTTP_CREATED)
        {
            throw new RuntimeException("Failed : HTTP error code : "
                    + conn.getResponseCode());
        }

        BufferedReader br = new BufferedReader(new InputStreamReader(
                (conn.getInputStream())));

        String output;
        System.out.println("Output from Server .... \n");
        while ((output = br.readLine()) != null)
        {
            System.out.println(output);
        }

        System.out.println("Location header: "
                + conn.getHeaderField("Location"));

        conn.disconnect();
    }
}
