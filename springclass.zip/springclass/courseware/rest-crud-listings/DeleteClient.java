package client;

import java.net.HttpURLConnection;
import java.net.URL;

public class DeleteClient
{
    public static void main(String[] args) throws Exception
    {
        URL url = 
          new URL(
            "http://localhost:9081/TestRestCRUDWeb/rest/students/44");
        HttpURLConnection conn = 
          (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("DELETE");

        conn.connect();
        
        if (conn.getResponseCode() != HttpURLConnection.HTTP_NO_CONTENT)
        {
            throw new RuntimeException("Failed : HTTP error code : "
                    + conn.getResponseCode());
        }

        conn.disconnect();
    }
}
