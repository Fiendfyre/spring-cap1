package edu.bigcollege.service;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Random;

import javax.servlet.ServletContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.Response.Status;

import edu.bigcollege.Student;

@Path("students")
public class StudentService
{
    @Context
    ServletContext servletContext;
    
    @SuppressWarnings("unchecked")
    @DELETE
    @Path("{id}")
    public Response delete(@PathParam("id") int id)
    {
        ResponseBuilder rb = null;
 
        System.out.println("In delete: " + id);
        
        Student found = findStudent(id);
        if(found != null)
        {
            List<Student> students = (List<Student>) servletContext
                    .getAttribute("students");

            students.remove(found);
            rb = Response.noContent();
        }
        else
        {
            rb = Response.status(Status.NOT_FOUND);
        }
        
        return rb.build();
    }
    
    @PUT
    @Consumes({ "text/xml", "application/json" })
    public Response update(Student s)
    {
        System.out.println("In update: " + s);
        ResponseBuilder rb = null;

        if(s != null)
        {
            Student found = findStudent(s.getStudentId());
            
            if(found != null)
            {
                found.setGpa(s.getGpa());
                found.setName(s.getName());
                rb = Response.noContent();
            }
            else
            {
                rb = Response.status(Status.NOT_FOUND);
            }
        }
        else
        {
            rb = Response.status(Status.CONFLICT);
        }
        
        return rb.build();
    }
    
    
    @SuppressWarnings("unchecked")
    @POST
    @Consumes({ "text/xml", "application/json" })
    // need @Produces since we send back updated Student
    // representation in response body
    @Produces({ "text/xml", "application/json" })
    public Response insert(Student s)
    {
        System.out.println("In insert: " + s);
        ResponseBuilder rb = null;

        if(s != null)
        {
            List<Student> students = (List<Student>) servletContext
                    .getAttribute("students");

            Random r = new Random();
            s.setStudentId(Math.abs(r.nextInt()));

            students.add(s);

            try
            {
                rb = Response.created(new URI("/students/" + 
                    s.getStudentId()));
                // marshal the student into the response body
                rb.entity(s);
            }
            catch (URISyntaxException e)
            {
                System.out.println("ERROR inserting: " + 
                  e.getMessage());
                rb = Response.serverError();
            }            
        }
        else
        {
            rb = Response.status(Status.BAD_REQUEST);
        }

        return rb.build();
    }

    @SuppressWarnings("unchecked")
    @GET
    @Path("{id}")
    @Produces({ "text/xml", "application/json" })
    public Response getStudent(@PathParam("id") int id)
    {
        Response ret = null;

        List<Student> students = (List<Student>) servletContext
                .getAttribute("students");

        Student theStudent = null;
        for (Student c : students)
        {
            if (c.getStudentId() == id)
            {
                theStudent = c;
                break;
            }
        }

        if (theStudent != null)
        {
            ret = Response.ok(theStudent).build();
        }
        else
        {
            ret = Response.status(Response.Status.NOT_FOUND).build();
        }

        return ret;
    }

    @SuppressWarnings("unchecked")
    private Student findStudent(int id)
    {
        List<Student> students = (List<Student>) servletContext
                .getAttribute("students");

        Student found = null;
        for(Student temp : students)
        {
            if(temp.getStudentId() == id)
            {
                found = temp;
                break;
            }
        }
        return found;
    }
   
}
