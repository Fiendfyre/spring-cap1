package domain;

public class MyDomainClass implements MyDomainInterface
{
    public void myMethod()
    {
        System.out.println("Thank you!");
    }
}
