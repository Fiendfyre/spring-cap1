package domain;

public interface MyDomainInterface
{
    public void myMethod();
}
