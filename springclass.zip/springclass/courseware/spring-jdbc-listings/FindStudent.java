package servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import university.Student;
import dao.StudentDAO;

@SuppressWarnings("serial")
@WebServlet("/findStudent")
public class FindStudent extends javax.servlet.http.HttpServlet
{
    protected void doGet(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException
    {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        ServletContext servletContext = getServletContext();
        WebApplicationContext ctx = WebApplicationContextUtils
                .getRequiredWebApplicationContext(servletContext);

        try
        {
            int studentID = Integer.parseInt(request.getParameter("studentID"));
            StudentDAO dao = (StudentDAO) ctx.getBean("studentDAO");
            Student s = dao.findStudentByID(studentID);
            if (s != null)
            {
                out.println("<p>Student ID: " + s.getStudentID() + "</p>");
                out.println("<p>Name: " + s.getName() + "</p>");
                out.println("<p>GPA: " + s.getGpa() + "</p>");                
            }
        }
        catch (NumberFormatException e)
        {
            out.println("Invalid number entered. Press 'Back' and try again.");
        }
        catch (EmptyResultDataAccessException e)
        {
            out.println("Student not found");            
        }
        catch (Exception e)
        {
            out.println("Something went wrong: " + e);
        }
    }
}
