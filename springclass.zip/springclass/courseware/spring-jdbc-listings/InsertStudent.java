package servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import university.Student;
import dao.StudentDAO;

@SuppressWarnings("serial")
@WebServlet("/insertStudent")
public class InsertStudent extends javax.servlet.http.HttpServlet
{
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException
    {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        ServletContext servletContext = getServletContext();
        WebApplicationContext ctx = WebApplicationContextUtils
                .getRequiredWebApplicationContext(servletContext);

        String name = request.getParameter("name");
        String s = request.getParameter("gpa");
        
        double gpa = Double.parseDouble(s);
        
        try
        {
            StudentDAO dao = (StudentDAO) ctx.getBean("studentDAO");

            Student student = new Student();
            student.setGpa(gpa);
            student.setName(name);
            int rows = dao.insertStudent(student);
            out.println("Insert successful, " + rows + " inserted.");
        }
        catch (Exception e)
        {
            out.println("Something went wrong: " + e);
        }
    }
}
