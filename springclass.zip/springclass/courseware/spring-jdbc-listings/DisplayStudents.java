package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collection;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import university.Student;
import dao.StudentDAO;


@SuppressWarnings("serial")
@WebServlet("/displayStudents")
public class DisplayStudents extends javax.servlet.http.HttpServlet         
{
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        ServletContext servletContext = getServletContext();
        WebApplicationContext ctx = 
            WebApplicationContextUtils.getRequiredWebApplicationContext(
                servletContext);
        
        try
        {
            StudentDAO dao = (StudentDAO)ctx.getBean("studentDAO");
            out.println("There are " + dao.getStudentCount() + " students");
            
            Collection<Student> students = dao.findAllStudents();
            out.println("<table border='1'>");            
            for(Student s : students)
            {
                out.println("<tr>");
                out.println("<td>" + s.getStudentID() + "</td>");
                out.println("<td>" + s.getName() + "</td>");
                out.println("<td>" + s.getGpa() + "</td>");
                out.println("</tr>");
            }
            out.println("</table>");            
        }
        catch (Exception e)
        {
            out.println("Something went wrong: " + e);
        }

//        Connection con = null;
//        try
//        {
//            Context ctx = new InitialContext();
//            DataSource ds = 
//                (DataSource)ctx.lookup("java:comp/env/studentDS");
//            con = ds.getConnection();
//            Statement st = con.createStatement();
//            ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM student");
//            rs.next();
//            out.println("There are " + rs.getInt(1) + " students");            
//        }
//        catch (NamingException e)
//        {
//            e.printStackTrace();
//        }
//        catch (SQLException e)
//        {
//            e.printStackTrace();
//        }
//        finally
//        {
//            try
//            {
//               if (con != null) con.close();
//            } catch (Exception e1) {}
//        }
        
        
    }    
}
