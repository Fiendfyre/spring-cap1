package testrmi.server;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class HelloRmiServer
{

    public static void main(String[] args)
    {
        AbstractApplicationContext ctx = new FileSystemXmlApplicationContext(
                "src/server.xml");
    }

}
