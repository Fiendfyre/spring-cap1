package beans;

import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.ObjectMessage;

import org.springframework.jms.core.JmsTemplate;

import domain.Purchase;

public class MyJmsReceiver
{
    private JmsTemplate template;
    private Destination destination;

    public Destination getDestination()
    {
        return destination;
    }

    public void setDestination(Destination destination)
    {
        this.destination = destination;
    }

    public JmsTemplate getTemplate()
    {
        return template;
    }

    public void setTemplate(JmsTemplate template)
    {
        this.template = template;
    }

    public Purchase receivePurchase()
        throws JMSException
    {
        ObjectMessage msg = (ObjectMessage) template.receive(destination);
        return (Purchase)msg.getObject();
    }

}
