package testrmi.server;

public interface HelloService
{
    public String sayHello();
}
