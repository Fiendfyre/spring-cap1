package beans;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;

import domain.Purchase;

public class MyMessageListener implements MessageListener
{

    public void onMessage(Message m)
    {
        System.out.println("In onMessage");
        ObjectMessage msg = (ObjectMessage)m;
        try
        {
            Purchase p = (Purchase)msg.getObject();
            
            PrintWriter out = new PrintWriter(
                new FileWriter("c:/temp/purchase.log"));
                      
            out.println("Date: " + p.getDate());
            out.println("Amount: " + p.getAmount());
            out.println("Reason: " + p.getReason());
            out.close();
        }
        catch (JMSException e)
        {
            e.printStackTrace();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

}
