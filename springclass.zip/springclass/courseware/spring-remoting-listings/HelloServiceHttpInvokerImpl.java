package testhttpinvoker.server;

import org.springframework.stereotype.Component;

@Component
public class HelloServiceHttpInvokerImpl implements HelloService
{

    @Override
    public String sayHello()
    {
        System.out.println("Received a request");
        return "Hello, world";
    }

}
