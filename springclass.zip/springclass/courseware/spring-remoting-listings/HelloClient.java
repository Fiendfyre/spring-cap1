package testrmi.client;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import testrmi.server.HelloService;

@Component
public class HelloClient
{
    @Autowired
    private HelloService helloService;
    
    public String getHelloMsg()
    {
        return helloService.sayHello();
    }

}
