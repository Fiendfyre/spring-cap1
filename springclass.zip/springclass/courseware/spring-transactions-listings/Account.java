package acct;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Transactional(propagation=Propagation.MANDATORY)
public class Account
{
    private Long accountNumber;
    private double balance;
    private String holderName;
    
    public Long getAccountNumber()
    {
        return accountNumber;
    }
    public void setAccountNumber(Long accountNumber)
    {
        this.accountNumber = accountNumber;
    }
    public double getBalance()
    {
        return balance;
    }
    public void setBalance(double balance)
    {
        this.balance = balance;
    }
    public String getHolderName()
    {
        return holderName;
    }
    public void setHolderName(String holderName)
    {
        this.holderName = holderName;
    }

    @Override
    public String toString()
    {
        return "Acct#: " + accountNumber + ", holder: " + holderName + ", balance: " + balance;
    }
}
