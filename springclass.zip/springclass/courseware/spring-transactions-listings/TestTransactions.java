package servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import acct.AccountManager;

@SuppressWarnings("serial")
public class TestTransactions extends javax.servlet.http.HttpServlet
{
    protected void doGet(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException
    {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        ServletContext servletContext = getServletContext();
        WebApplicationContext ctx = WebApplicationContextUtils
                .getRequiredWebApplicationContext(servletContext);
        try
        {
            AccountManager mgr = (AccountManager)ctx.getBean("accountMgr");
            
            out.println("Before transfer: <br>");
            out.println(mgr.getAccountInfo(1) + "<br>");
            out.println(mgr.getAccountInfo(2) + "<br>");
            
            mgr.transfer(1, 2, 1);
            
            out.println("After transfer: <br>");
            out.println(mgr.getAccountInfo(1) + "<br>");
            out.println(mgr.getAccountInfo(2) + "<br>");
        }
        catch (Exception e)
        {
            out.println("Something went wrong: " + e);
        }
    }
}
