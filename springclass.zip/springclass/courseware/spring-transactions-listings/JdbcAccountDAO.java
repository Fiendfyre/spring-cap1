package acct;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

public class JdbcAccountDAO extends SimpleJdbcDaoSupport implements AccountDAO
{
    private static class AccountRowMapper implements
            ParameterizedRowMapper<Account>
    {
        public Account mapRow(ResultSet rs, int index) throws SQLException
        {
            Account acct = new Account();
            acct.setAccountNumber(rs.getLong("ACCT_NUM"));
            acct.setBalance(rs.getDouble("BALANCE"));
            acct.setHolderName(rs.getString("HOLDERNAME"));
            return acct;
        }

    }

    @Transactional(propagation=Propagation.MANDATORY)
    public void updateAccount(Account a)
    {
        String SQL = "UPDATE account SET balance=?,holdername=? WHERE acct_num=?";
        getSimpleJdbcTemplate().update(SQL, a.getBalance(), a.getHolderName(),
                a.getAccountNumber());
    }

    @Transactional(propagation=Propagation.MANDATORY)
    public Account getAccountByID(int accountNumber)
    {
        String SQL = "SELECT * FROM account WHERE ACCT_NUM=?";
        return getSimpleJdbcTemplate().queryForObject(SQL,
                new AccountRowMapper(), accountNumber);
    }
}
