package acct;

@SuppressWarnings("serial")
public class NoMoneyException extends Exception
{
    public NoMoneyException()
    {
        super("Insufficient funds for transfer");
    }
}
