package university;

import java.util.ArrayList;

public class SimpleStudentManager implements StudentManager
{
    private static ArrayList<Student> students = 
        new ArrayList<Student>();
    
    public Student findStudent(int id)
    {
        Student found = null;
        
        for(Student s : students)
        {
            if (s.getId() == id)
            {
                found = s;
                break;
            }
        }
        
        return found;
    }

    private static void addStudent(int id, String name, double gpa)
    {
        students.add(new Student(id, name, gpa));
    }
    
    static
    {
        addStudent(13, "Paul Westerberg", 3.44);
        addStudent(44, "Joan Jett", 3.65);
        addStudent(193, "David Byrne", 3.90);
        addStudent(483, "Jonny Rotten", 1.45);
    }
    
    
}
