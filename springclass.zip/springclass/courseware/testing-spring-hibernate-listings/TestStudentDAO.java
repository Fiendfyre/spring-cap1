package university;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import dao.StudentDAO;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "/spring.xml")
@Transactional
public class TestStudentDAO
{
    @Autowired
    private StudentDAO dao;
    
    @Test
    public void testStudentCount()
    {
        int countBefore = dao.getStudentCount();
        
        Student s = new Student();
        s.setGpa(3.42);
        s.setName("Horace Greeley");
        dao.insertStudent(s);
        
        int countAfter = dao.getStudentCount();
        assertEquals("Count should increment", 1, 
            countAfter - countBefore);
    }
}
