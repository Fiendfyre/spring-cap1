package dao;

import java.util.Collection;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import university.Student;

/*
 * Method 3: Use Hibernate maximally - do not extend
 * HibernateDaoSupport
 */
public class StudentDAOHibernateImpl3 
    implements StudentDAO
{
    private SessionFactory sessionFactory;
    
    @Transactional(propagation = Propagation.REQUIRED)
    public Collection<Student> findAllStudents()
    {
        Session session = sessionFactory.getCurrentSession();
        Query q = session.createQuery("from Student");
        return q.list();
    }

    @Transactional(propagation = Propagation.REQUIRED)
    public int getStudentCount()
    {
        Session session = sessionFactory.getCurrentSession();
        Query q = session.createQuery("select count(s) from Student s");
        Long count = (Long) q.uniqueResult();

        return count.intValue();
    }
    
    @Transactional(propagation = Propagation.REQUIRED)
    public void insertStudent(Student s)
    {
        Session session = sessionFactory.getCurrentSession();
        session.save(s);        
    }

    public SessionFactory getSessionFactory()
    {
        return sessionFactory;
    }

    public void setSessionFactory(SessionFactory sessionFactory)
    {
        this.sessionFactory = sessionFactory;
    }
}
