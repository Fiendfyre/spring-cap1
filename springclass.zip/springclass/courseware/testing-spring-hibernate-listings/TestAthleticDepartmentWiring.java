package university;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;

@ContextConfiguration(locations = "/university.xml")
public class TestAthleticDepartmentWiring 
   extends AbstractJUnit4SpringContextTests
{
    @Autowired
    private AthleticDepartment dept;

    @Test
    public void testPaulEligibility()
    {
        // AthleticDepartment dept =
        // (AthleticDepartment)applicationContext.getBean(
        //    "athleticDepartment");
        assertTrue("Paul should be eligible", 
                dept.isEligible(13));
    }

    @Test
    public void testJonnyEligibility()
    {
        // AthleticDepartment dept =
        // (AthleticDepartment)applicationContext.getBean(
        //   "athleticDepartment");
        assertFalse("Jonny Rotten should not be eligible", 
                dept.isEligible(483));
    }
}
