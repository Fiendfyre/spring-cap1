package equations;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestQuadratic
{
    @Test
    public void testGetRoot1()
    {
        SolveQuadratic sq = new SolveQuadraticImpl();
        assertEquals("First root should be 1.0", 
                1.0, sq.getRoot1(1, 3, -4));
    }

    @Test
    public void testGetRoot2()
    {
        SolveQuadratic sq = new SolveQuadraticImpl();
        assertEquals("Second root should be -4.0", 
                -4.0, sq.getRoot2(1, 3, -4));
    }
}
