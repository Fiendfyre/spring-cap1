package equations;

public interface SolveQuadratic
{
    public double getRoot1(double a, double b, double c);
    public double getRoot2(double a, double b, double c);
}
