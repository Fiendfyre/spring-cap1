package dao;

import java.util.Collection;

import university.Student;

public interface StudentDAO
{
    public int getStudentCount();   
    public Collection<Student> findAllStudents();
    public void insertStudent(Student s);
}
