package equations;

public class SolveQuadraticImpl implements SolveQuadratic
{

    public double getRoot1(double a, double b, double c)
    {
        return (-b + Math.sqrt(b * b - 4 * a * c)) / 2 * a; 
    }

    public double getRoot2(double a, double b, double c)
    {
        return (-b - Math.sqrt(b * b - 4 * a * c)) / 2 * a;         
    }
}
