package university;


public class AthleticDepartment
{
    private StudentManager studentManager;
    
    public void setStudentManager(StudentManager studentManager)
    {
        this.studentManager = studentManager;
    }

    public boolean isEligible(int id)
    {
        Student s = studentManager.findStudent(id);
        if (s.getGpa() > 3.00)
            return true;
        else
            return false;
    }   
}
