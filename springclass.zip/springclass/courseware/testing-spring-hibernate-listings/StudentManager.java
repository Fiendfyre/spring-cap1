package university;

public interface StudentManager
{
    public Student findStudent(int id);
}
