package mypackage;

import org.springframework.beans.factory.DisposableBean;

public class MyDestroyBean implements DisposableBean
{
    
    @Override
    public void destroy() throws Exception
    {
        System.out.println("In destroy");
    }

    public void myDestroyMethod()
    {
        System.out.println("In myDestroyMethod");
    }
    
    @PreDestroy
    public void myPreDestroyMethod()
    {
        System.out.println("In myPreDestroyMethod");
    }
    
}
