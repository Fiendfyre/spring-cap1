package mypackage;

public interface Encrypted
{
    public String getText();
    public void setText(String text);
}
