package mypackage;

import org.springframework.stereotype.Component;

@Component
public class EncryptedBean implements Encrypted
{
    private String text = "Uryyb, jbeyq";

    public String getText()
    {
        return text;
    }

    public void setText(String text)
    {
        this.text = text;
    }
}
