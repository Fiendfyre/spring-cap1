package main;

import mypackage.MyDestroyBean;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class TestDestroy
{
    public static void main(String[] args)
    {
        AbstractApplicationContext ctx =
            new FileSystemXmlApplicationContext("destroy.xml");
        
        MyDestroyBean mdb = (MyDestroyBean)ctx.getBean("myDestroyBean");
        ctx.close();
    }

}
