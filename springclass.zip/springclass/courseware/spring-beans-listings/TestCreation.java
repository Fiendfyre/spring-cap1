package main;

import mypackage.MyCreationBean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class TestCreation
{
    public static void main(String[] args)
    {
        ApplicationContext ctx =
            new FileSystemXmlApplicationContext("create.xml");
        
        MyCreationBean mcb = (MyCreationBean)ctx.getBean("myCreateBean");               
    }

}
