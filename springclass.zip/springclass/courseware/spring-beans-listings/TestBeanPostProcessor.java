package main;

import mypackage.EncryptedBean;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class TestBeanPostProcessor
{

    public static void main(String[] args)
    {
        AbstractApplicationContext ctx =
            new FileSystemXmlApplicationContext("beanpp.xml");

        EncryptedBean eb = (EncryptedBean)ctx.getBean("encryptedBean");
        System.out.println("Main: " + eb.getText());
    }

}
