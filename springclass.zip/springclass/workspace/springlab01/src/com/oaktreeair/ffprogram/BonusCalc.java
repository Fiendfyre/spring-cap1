/**
 * 
 */
package com.oaktreeair.ffprogram;

import java.util.Collection;

/**
 * @author Administrator
 *
 */
public interface BonusCalc {
	public int calcBonus(Flier flier, Segment seg);
	public int calcBonus(Flier flier, Collection<Segment> segments);
}
