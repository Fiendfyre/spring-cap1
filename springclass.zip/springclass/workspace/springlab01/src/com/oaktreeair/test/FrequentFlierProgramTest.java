/**
 * 
 */
package com.oaktreeair.test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.oaktreeair.ffprogram.BonusCalc;
import com.oaktreeair.ffprogram.BonusCalcImpl;
import com.oaktreeair.ffprogram.Flier;
import com.oaktreeair.ffprogram.Segment;

/**
 * @author Administrator
 *
 */
public class FrequentFlierProgramTest {

	/**
	 * @throws java.lang.Exception
	 */
	Flier flier01 =null;
	Segment seg01 = null;
	BonusCalc bc = null;
	@Before
	public void setUp() throws Exception {
		AbstractApplicationContext ctx =
				new FileSystemXmlApplicationContext("src/ApplicationContext.xml");
		if((Flier)ctx.getBean("flier01") instanceof Flier){
			 flier01 = (Flier)ctx.getBean("flier01");
			}
		if(ctx.getBean("seg01") instanceof Segment){
			seg01 = (Segment) ctx.getBean("seg01");
		}
		if(ctx.getBean("calcBonus") instanceof BonusCalcImpl){
			bc = (BonusCalc) ctx.getBean("calcBonus");
		}
		flier01.setLevel(Flier.Level.Gold);
		flier01.addSegment(seg01);
	}

	@Test
	public void test() {
		System.out.println("Bonus: " + bc.calcBonus(flier01, seg01));
		assertEquals(250, bc.calcBonus(flier01, seg01)); ;
	}

}
