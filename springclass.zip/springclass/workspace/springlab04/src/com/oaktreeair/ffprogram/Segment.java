/**
 * 
 */
package com.oaktreeair.ffprogram;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.Random;

import javax.annotation.PostConstruct;

/**
 * @author Administrator
 * 
 */
public class Segment {
	private Long segmentNumber;
	private Date segmentDate;
	private int flightNumber;
	private String originatingCity;
	private int miles;

	public Long getSegmentNumber() {
		Long segNum = null;
		try {
			DataInputStream dis = new DataInputStream(new FileInputStream(
					"temp.dat"));
			long val = dis.readLong();
			segNum = val;
			dis.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return segNum;
	}

	public void setSegmentNumber(Long segmentNumber) {
		this.segmentNumber = segmentNumber;
	}

	public Date getSegmentDate() {
		return segmentDate;
	}

	public void setSegmentDate(Date segmentDate) {
		this.segmentDate = segmentDate;
	}

	public int getFlightNumber() {
		return flightNumber;
	}

	public void setFlightNumber(int flightNumber) {
		this.flightNumber = flightNumber;
	}

	public String getOriginatingCity() {
		return originatingCity;
	}

	public void setOriginatingCity(String originatingCity) {
		this.originatingCity = originatingCity;
	}

	public int getMiles() {
		return miles;
	}

	public void setMiles(int miles) {
		this.miles = miles;
	}

	@PostConstruct
	public void init() {
		System.out.println("In init() method");
		try {
			Random rand = new Random();
			long randID = rand.nextLong();
			DataOutputStream dos = new DataOutputStream(new FileOutputStream(
					"temp.dat"));
			dos.writeLong(randID);
			dos.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
