/**
 * 
 */
package com.oaktreeair.ffprogram;

import java.util.Collection;

/**
 * @author Administrator
 *
 */
public class BonusCalcImpl implements BonusCalc {

	/* (non-Javadoc)
	 * @see com.oaktreeair.ffprogram.BonusCalc#calcBonus(com.oaktreeair.ffprogram.Flier, com.oaktreeair.ffprogram.Segment)
	 */
	@Override
	public int calcBonus(Flier flier, Segment seg) {
		double bonus = 0;
		double miles = seg.getMiles();
		switch(flier.getLevel())
		{
		case Member:
		bonus = miles * 0.10;
		break;
		case Gold:
		bonus = miles * 0.25;
		break;
		case Platinum:
		bonus = miles * 0.50;
		break;
		}
		return (int)bonus;
	}

	/* (non-Javadoc)
	 * @see com.oaktreeair.ffprogram.BonusCalc#calcBonus(com.oaktreeair.ffprogram.Flier, java.util.Collection)
	 */
	@Override
	public int calcBonus(Flier flier, Collection<Segment> segments) {
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
