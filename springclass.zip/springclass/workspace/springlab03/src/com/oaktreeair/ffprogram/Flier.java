/**
 * 
 */
package com.oaktreeair.ffprogram;

import java.util.ArrayList;

/**
 * @author Administrator
 *
 */
public class Flier {
	private String flierName;
	private Long flierID;
	private ContactInfo contactInfo;
	public enum Level
	{
	Member, Gold, Platinum
	};
	private Level level;
	
	private ArrayList<Segment> segments = new ArrayList<Segment>();
	private AddressInfo homeAddress;
	
	
	
	public String getFlierName() {
		return flierName;
	}
	public void setFlierName(String flierName) {
		this.flierName = flierName;
	}
	public Long getFlierID() {
		return flierID;
	}
	public void setFlierID(Long flierID) {
		this.flierID = flierID;
	}
	public ContactInfo getContactInfo() {
		return contactInfo;
	}
	public void setContactInfo(ContactInfo contactInfo) {
		this.contactInfo = contactInfo;
	}
	public Level getLevel() {
		return level;
	}
	
	public void setLevel(Level level) {
		this.level = level;
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	/**
	 * @return the segments
	 */
	public ArrayList<Segment> getSegments() {
		return segments;
	}

	public void setSegments(ArrayList<Segment> segments) {
		this.segments = segments;
	}
	public void addSegment(Segment seg)
	{
	segments.add(seg);
	}
	/**
	 * @return the homeAddress
	 */
	public AddressInfo getHomeAddress() {
		return homeAddress;
	}
	/**
	 * @param homeAddress the homeAddress to set
	 */
	public void setHomeAddress(AddressInfo homeAddress) {
		this.homeAddress = homeAddress;
	}
}
