/**
 * 
 */
package com.oaktreeair.test;

import org.springframework.beans.BeansException;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.oaktreeair.ffprogram.BonusCalc;
import com.oaktreeair.ffprogram.BonusCalcImpl;
import com.oaktreeair.ffprogram.ContactInfo;
import com.oaktreeair.ffprogram.Flier;
import com.oaktreeair.ffprogram.Segment;

/**
 * @author Administrator
 * 
 */
public class FrequentFlierProgram {

	public static void main(String[] args) {
		AbstractApplicationContext ctx =null;
		try {
			String[] contextFiles = {"ApplicationContext.xml","AnotherApplicationContext.xml"};
			ctx = new ClassPathXmlApplicationContext(contextFiles);
			Flier flier01 = null;
			if ((Flier) ctx.getBean("flier01") instanceof Flier) {
				flier01 = (Flier) ctx.getBean("flier01");
			}
			if (flier01 != null) {
				System.out.println(flier01.getFlierName());
				System.out.println(flier01.getFlierID());
				ContactInfo inf = flier01.getContactInfo();
				flier01.setLevel(Flier.Level.Gold);
				Segment seg01 = null;
				if (ctx.getBean("seg01") instanceof Segment) {
					seg01 = (Segment) ctx.getBean("seg01");
				}
				BonusCalc bc = null;
				if (ctx.getBean("calcBonus") instanceof BonusCalcImpl) {
					bc = (BonusCalc) ctx.getBean("calcBonus");
				}
				flier01.addSegment(seg01);
				int bonus = bc.calcBonus(flier01, seg01);
				System.out.println("Bonus: " + bonus);
				System.out.println("HomeAddress: "+flier01.getHomeAddress());
			}

		} catch (BeansException e) {
			e.printStackTrace();
		}finally{
			if(ctx !=null){
				ctx.close();
			}
		}
	}
}
